tail -f logs/logfile.txt
