<?php
setlocale(LC_ALL, 'pt_BR', 'pt_BR.utf-8', 'pt_BR.utf-8', 'portuguese');
date_default_timezone_set('America/Sao_Paulo');
/*
* O Objetivo deste script é retornar na tela o ultimo XML
* gerado para loja informada na varialve $_GET['padrao']
*/

$padrao = strtolower($_GET['padrao']);

$xmls = glob($padrao.'*.xml');
rsort($xmls);

// Verifica se retornou o ultimo xml
if( empty($xmls) OR empty($padrao) OR empty($xmls[0]) ) {
	echo 'Nenhum xml encontrado ou $_GET[padrao] esta vazio';
	exit;
}
header("Content-Type: application/xml; charset=utf-8");
echo file_get_contents('./'.$xmls[0]);
?>